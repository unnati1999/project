!DOCTYPE html>
<html>
<head>
	<title>Student Management System</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body bgcolor="#696969">

