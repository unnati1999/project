<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
   <?php include 'menu.php'?>
   <br>
   <br>
   <h1> About Faculty</h1>
  <div class="container-fluid">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/hod.jfif" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Dr. Ajay Kumar Shrivastava</h4>

    <a href="https://www.linkedin.com/in/dr-ajay-kumar-shrivastava-870a291a/" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images//panda.jpg" alt="Card image" width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mr.Ravi Pandey</h4>
  
    <a href="updatestudent.php" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/sangeeta.jpg" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mrs Sangeeta Arora </h4>
   
    <a href="deletestudent.php" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
		</div>
	</div>
	<br>
	<br>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/neelammam.jpg" alt="Card image" width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Miss Neelam Rawat</h4>

    <a href="https://www.linkedin.com/in/neelam-rawat-274a7225/" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/Vidushimam.jpg" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mrs.Vidushi Mishra</h4>
  
    <a href="updatestudent.php" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/prashantsir.jpg" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mr.Prashant Kumar</h4>
   
    <a href="https://www.linkedin.com/in/prashant-agrawal-2944351a/" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/shalika.jpg" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mrs Shalika</h4>

    <a href="addstudent.php" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/nareshsir.jpg" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mr Naresh Chandra</h4>
  
    <a href="https://www.linkedin.com/in/naresh-chandra-b0914aa3/" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/mandeep.jpg" alt="Card image"  width="500" height="333">
  <div class="card-body">
    <h4 class="card-title">Mr Mandeep Kumar</h4>
   
    <a href="deletestudent.php" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<br>
<br>
  <?php include 'footer1.php'?>