<?php
session_start();
        if(isset($_SESSION['uid']))
        {
        	
        }
        else
        {
        	header('location: ../login.php');
        }

?>
<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
<?php


include('menu.php');
?>
<br>
<br>
<br>
<div class="container">

     <form method="post" action="addstudent.php" enctype="multipart/form-data">
             <h2 class="form-signin-heading"> Student Entry Form</h2>
         <label for="inputrollno" class="sr-only">Enter FullName</label>
        <input type="text" name="rollno" class="form-control" placeholder="Enter Rollno" required autofocus>  
        <label for="inputrollno" class="sr-only">Enter FullName</label>
        <input type="text"name="name"  class="form-control" placeholder="Enter FullName" required autofocus>
        <label for="inputEmail" class="sr-only">Enter City</label>
        <input type="text"name="city" class="form-control" placeholder="Enter City" required autofocus>
        <label for="inputEmail" class="sr-only">Enter Parent Contact</label>
        <input type="text"name="pcont" class="form-control" placeholder="Enter Parent Contact" required autofocus>
        <label for="inputEmail" class="sr-only">Enter Standard</label>
        <input type="text" name="std" class="form-control" placeholder="Enter Standard" required autofocus>
         <label for="inputEmail" class="sr-only">Image</label>
        <input type="file" name="simg" class="form-control" required autofocus>
       
       
        <br>
        
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="submit">Register</button>
      </form>

    </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>

</html>

<?php

if (isset($_POST['submit'])) {
	
	include('dbcon.php');
	$rollno=$_POST['rollno'];
	$name=$_POST['name'];
	$city=$_POST['city'];
	$pcont=$_POST['pcont'];
	$std=$_POST['std'];
	$imagename = $_FILES['simg']['name'];
	$tempname = $_FILES['simg']['tmp_name'];
	move_uploaded_file($tempname,"dataimg/$imagename");
	$qry = "INSERT INTO `student`(`rollno`, `name`, `city`, `pcont`, `standerd`,`image`) VALUES ('$rollno','$name','$city','$pcont','$std','$imagename')";

	
	$run = mysqli_query($con,$qry); 
    
	if ($run==true) {
		?>

		<script>
			alert('Data Inserted Successfully.');
		</script>
		<?php
	}
?>
<?php


}
?>
<br>
<br>
<br>
<br>

 <?php include 'footer1.php'?>