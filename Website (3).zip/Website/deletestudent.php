<?php
session_start();
        if(isset($_SESSION['uid']))
        {
        	
        }
        else
        {
        	header('location: ../login.php');
        }

?>
<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
<?php

include('menu.php');
?>

<div>
<table align="center">
<form ation="deletestudent.php" method="post">
	<br>
	<br>
	 <h2 class="form-signin-heading"> Student Delete Form</h2>
	<tr>

		<th style="color: black">Enter Standerd</th>
		<td><input type="number" name="standerd" placeholder="standerd" required/></td>
		<th style="color: black">Enter Student Name</th>
		<td><input type="text" name="stuname" placeholder="Enter Student Name" required/></td>
		<td colspan="2"><input type="submit" name="submit" value="search"></td>
	</tr>
	
</form>
</table>
<table align="center" width="80%" border="1">
	<tr style="background-color: #000;color: #fff">
		<th>No</th>
		<th>Image</th>
		<th>Name</th>
		<th>Roll No.</th>
		<th>Delete</th>

	</tr>
	<?php
if (isset($_POST['submit'])) {
	include('dbcon.php');
	$standerd =$_POST['standerd'];
	$name =$_POST['stuname'];
	$sql="SELECT * FROM `student` WHERE `standerd`='$standerd' AND `name` LIKE '%$name%'";
	$run = mysqli_query($con,$sql);
	   
	if (mysqli_num_rows($run)<1) {
		echo "<tr><td colspan='5'>No Record Found</td></tr>";
	}
	else{
		$count=0;
		while ($data =mysqli_fetch_assoc($run)) {
			$count++;
			?>
			<tr align="center">
				<td><?php echo $count; ?></td>
				<td><img src="dataimg/<?php echo $data['image']; ?>" style="max-width: 100px;"></td>
				<td><?php echo $data['name'];?></td>
				<td><?php echo $data['rollno'];?></td>
				<td><a href="deleteform.php?sid=<?php echo $data['id'];?>">Delete</a></td>
			</tr>

			<?php
		}
	}
}
?>

</table>
</div>
</body>
</html>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
 <?php include 'footer1.php'?>