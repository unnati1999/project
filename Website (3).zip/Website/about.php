<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
   <?php include 'menu.php'?>

<div class="jumbotron">
  <h1>MCA Department Kiet Group Of Institution</h1>
  <p>Department of Computer Applications was established in 1999. It offers a post graduate three years degree course that is approved by AICTE and affiliated to Dr APJ Abdul Kalam Technical University, Lucknow.
</p>
</div>
<section class="my-5">
  <div class="container-fluid">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-12">
      <img src="images/hod.jfif" class="img-fluid aboutimg" width="400" height="500" >
    </div>
    <div class="col-lg-6 col-md-6 col-12">
     
      <p class="font-weight-bold py-3">‘Shaping young minds with skill-oriented and value-based education’- these words acceptably symbolize the mission and execution of KIET Group of Institutions. The Group aspires to advance knowledge and educate students in various disciplines of engineering, management, computer applications and pharmacy.</p>
    </div>
  </div>
</div>
</section>
   <?php include 'footer1.php'?>
