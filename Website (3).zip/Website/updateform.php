<?php
session_start();
        if(isset($_SESSION['uid']))
        {
        	
        }
        else
        {
        	header('location: ../login.php');
        }

?>

<?php

//include('header.php');

include('dbcon.php');
$sid =$_GET['sid'];
$sql ="SELECT * FROM `student` WHERE id='$sid'";
$run = mysqli_query($con,$sql);
$data =mysqli_fetch_assoc($run);

?>
<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
<?php

include('menu.php');
?>
 <h2 class="form-signin-heading"> Student Update Form</h2>
<div class="container">

     <form method="post" action="updatedata.php" enctype="multipart/form-data">
             <h2 class="form-signin-heading">Update Student Detail</h2>
         <label for="inputrollno" class="sr-only">Enter Rollno</label>
        <input type="text" name="rollno" class="form-control" value=<?php echo $data['rollno'];?> >  
        <label for="inputrollno" class="sr-only">Enter FullName</label>
        <input type="text"name="name"  class="form-control" value=<?php echo $data['name'];?>  >
        <label for="inputEmail" class="sr-only">Enter City</label>
        <input type="text"name="city" class="form-control" value=<?php echo $data['city']; ?>  >
        <label for="inputEmail" class="sr-only">Enter Parent Contact</label>
        <input type="text"name="pcont" class="form-control" value=<?php echo $data['pcont'];?> >
        <label for="inputEmail" class="sr-only">Enter Standard</label>
        <input type="text" name="std" class="form-control" value=<?php echo $data['standerd']; ?> >
         <label for="inputEmail" class="sr-only">Image</label>
         <input type="hidden" name="sid" value="<?php echo $data['id']; ?>"/>
        <input type="file" name="simg" class="form-control">
    <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="submit"> Submit</button>
      </form>

    </div> <!-- /

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
 <?php include 'footer1.php'?>