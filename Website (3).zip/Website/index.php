<!DOCYPE html>
<html>
<head>
	<title>Welcome to KIET MCA Department</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<style>
</style>
<body>
<?php include 'menu.php'?>
<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ca.jpg" alt="Los Angeles" width="1500" height="500">
       
    </div>
  </div>
 
</div>
<section class="my-5">
	<div class="container-fluid">
	<div class="row">
		<div class="col-lg-6 col-md-6 col-12">
       <img src="images/s.webp" alt="Los Angeles" width="600" height="300" >
		</div>
		<div class="col-lg-6 col-md-6 col-12">
			<div class="wrapper fadeInDown">
  <div id="formContent">
  <div style="background-color:skyblue">
<h2>ADMIN LOGIN FORM</h2>
</div>

    <!-- Login Form -->
    <form method="post" action="login.php" div style="background-color:skyblue">
      <input type="text" id="login" class="fadeIn second"  placeholder="Username" name="username">
      <input type="text" type="password" id="password" class="fadeIn third" name="pass" placeholder="password"name="pass">
      <input type="submit" name="login" value="submit"class="fadeIn fourth" value="Log In">
    </form>
    

  </div>
</div>
		</div>
	</div>
</div>
</section>

 <?php include 'footer1.php'?>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

</body>
</html>