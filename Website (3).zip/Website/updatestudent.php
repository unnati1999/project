<?php
session_start();
        if(isset($_SESSION['uid']))
        {
        	
        }
        else
        {
        	header('location: ../login.php');
        }

?>
<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
	   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">  <img src="images//logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="services.php">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="gallery.php">Gallery</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="SearchStudentDetail.php">Search Student</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
     
    </form>
  </div>
</nav>

<div>
<table align="center">
<form ation="updatestudent.php" method="post">
	<tr>
		<th style="color:black">Enter Standerd</th>
		<td><input type="number" name="standerd" placeholder="standerd" required/></td>
		<th style="color: black">Enter Student Name</th>
		<td><input type="text" name="stuname" placeholder="Enter Student Name" required/></td>
		<td colspan="2"><input type="submit" name="submit" value="search"></td>
	</tr>
	
</form>
</table>
<table align="center" width="80%" border="1">
	<tr style="background-color: #000;color: #fff">
		<th>No</th>
		<th>Image</th>
		<th>Name</th>
		<th>Roll No.</th>
		<th>Edit</th>

	</tr>
	<?php
if (isset($_POST['submit'])) {
	include('dbcon.php');
	$standerd =$_POST['standerd'];
	$name =$_POST['stuname'];
	$sql="SELECT * FROM `student` WHERE `standerd`='$standerd' AND `name` LIKE '%$name%'";
	$run = mysqli_query($con,$sql);   
	if (mysqli_num_rows($run)<1) {
		echo "<tr><td colspan='5'>No Record Found</td></tr>";
	}
	else{
		$count=0;
		while ($data =mysqli_fetch_assoc($run)) {
			$count++;
			?>
			<tr align="center">
				<td><?php echo $count; ?></td>
				<td><img src="dataimg/<?php echo $data['image']; ?>" style="max-width: 100px;"></td>
				<td><?php echo $data['name'];?></td>
				<td><?php echo $data['rollno'];?></td>
				<td><a href="updateform.php?sid=<?php echo $data['id'];?>">Edit</a></td>
			</tr>

			<?php
		}
	}
}
?>
</table>
</div>
<br>
<br>
<br>
<br>
<br>
<br>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
</body>



</html>
 <?php include 'footer1.php'?>