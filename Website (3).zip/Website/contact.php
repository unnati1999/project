<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
   <?php include 'menu.php'?>
   <br>
   <br>
   <br>
   <br>
   <h1><b>CONTACT US</b></h1>
    <br>
   
 <img src="images/contact.png"  >
 <br>
 <br>

 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3497.893789973412!2d77.49586181456243!3d28.75258788538904!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cf574d18f2b6f%3A0x4a65c0bc0122eb2f!2sKIET%20Group%20of%20Institutions!5e0!3m2!1sen!2sin!4v1599735044538!5m2!1sen!2sin" width="2000" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</body>
</html>
<br>
   <br>
   <br>
   <br>
 <?php include 'footer1.php'?>
