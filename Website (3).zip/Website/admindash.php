
<?php
session_start();
        if(isset($_SESSION['uid']))
        {
        	
        }
        else
        {
        	header('location: ../login.php');
        }

?>
<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
	   <?php include 'menu.php'?>
	   <br>
	   <br>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/images4.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Add Student Detail</h4>

    <a href="addstudent.php" class="btn btn-primary">Add Detail</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/images4.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Update Student Detail</h4>
  
    <a href="updatestudent.php" class="btn btn-primary">Update Detail</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/images4.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Delete Student Detail</h4>
   
    <a href="deletestudent.php" class="btn btn-primary">Delete Profile</a>
  </div>
</div>
			</div>
		</div>
	</div>
<br>
<br>
<br>
<br>
<br>
</body>
</html>
  <?php include 'footer1.php'?>
