<!DOCTYPE html>
<html>
<head>
	<title>Student Management System</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body align="center">
<?php include 'menu.php'?>
<h1 align="center"  style="font-weight: bold;">Welcome to KIET MCA Student Portal</h1>

<form method="post" action="SearchStudentDetail.php">
<table style="width: 30%;" align="center" border="1">
	<tr>
		<td colspan="2" align="center">Student Information</td>
	</tr>
	<tr>
		<td>Choose Semester</td>
		<td>
			<select name="std">
				<option value="1">1st</option>
				<option value="2">2nd</option>
				<option value="3">3rd</option>
				<option value="4">4th</option>
				<option value="5">5th</option>
				<option value="6">6th</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>Enter Rollno.</td>
		<td align="left">
			<input type="text" name="rollno" required/>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" name="submit" value="Show Info."></td>
	</tr>
</table>
</form>

</body>
</html>
<br>
<br>

<?php
if(isset($_POST['submit']))
{
	$standard =$_POST['std'];
	$rollno =$_POST['rollno'];
	include('dbcon.php');
	include('function.php');
   
	showdetails($standard,$rollno);
}
?>

 <?php include 'footer1.php'?>